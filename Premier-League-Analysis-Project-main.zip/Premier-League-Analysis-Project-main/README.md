# Premier League 2020/21 — Player Performance Analysis

A data analysis project exploring player and team performance in the English Premier League 2020/21 season using Python.

## -- Analysis Covered
- Top 10 Goal Scorers
- Top 10 Assist Leaders
- Most Aggressive Teams (Yellow + Red Cards)
- Most Aggressive Nationalities
- Top Goal Scoring Defenders
- Most Accurate Passers (Midfielders & Forwards)

## -- Tools Used
- Python
- Pandas
- Matplotlib
- Seaborn

## -- Dataset
English Premier League 2020/21 player statistics from Kaggle.

## -- Sample Charts
All charts are saved in the `charts` folder
